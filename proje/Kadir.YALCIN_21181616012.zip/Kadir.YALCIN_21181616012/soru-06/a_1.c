#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int a,b,c,i,top;
	for(i=0;i<1;i++){												//Hatali giris olursa basa donmek icin.

	printf("Baslangic yilini giriniz:");							//Baslangic yilini almak icin.
	scanf("%d",&a);
	printf("Bitis yilini giriniz:");								//Bitis yilini almak icin.
	scanf("%d",&b);
	printf("------------------------\n");
	if(a<=b)																// Uygun yillari kontrol etmek icin.
	{
		for(a=a;a<b;a++){												//Artik yillari bulmak icin.
			if(a%4==0){
			printf("%d \t",a);
			top+=1;														//Kac tane artik yil oldugunu hesaplamak icin.
			}	
		}
	printf("\nToplam %d adet artik yil vardir.",top);					//Kac tane artik yil oldugunu kullaniciya gostermek icin.
	}

	else
	{
	printf("Baslangic yili bitis yilindan daha buyuk olamaz. \n    Lutfen tekrar deneyiniz\n\n\n**************************\n"); 	// Hatali giris oldugunu belirtmek icin.
	i--;	
	}

}	
	return 0;
}

