#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	
	int a,b,c,i,top=0;
	
	for(i=0;i<1;i++)															//Hatali giris olursa basa donmek icin.
{
	printf("Baslangic degerini giriniz:");										//Baslangic degerini almak icin.
	scanf("%d",&a);
	printf("Bitis degerini giriniz:");											//Bitis degerini almak icin.
	scanf("%d",&b);
	printf("------------------------\n");
	if(a<b)																		// Uygun sayilari kontrol etmek icin.
	{
		for(a=a;a<b;a++){														//Arada kalan sayilari hesaplamak icin.
			if(a%3==0 || a%11==0){
			printf("%d \t",a);													//Uygun sayilari ekrana yazmak icin.
			top+=1;
			}	
		}
	printf("\nKurala uyan toplam %d sayi bulunmaktadir.",top);					//Kurala uygun kac tane sayi oldugunu bildirmek icin.
	}

	else
	{
	printf("Baslangic degeri bitis degerine ayni ya da daha buyuk olamaz. \n    Lutfen tekrar deneyiniz\n\n\n**************************\n");	// Hatali giris oldugunu belirtmek icin.
	i--;	
	}

}	

	
	
	return 0;
}
