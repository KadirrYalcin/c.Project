#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int i,at=0,bt,ct,ft,x;
	float ort,top=0;

	while(i==0){                                                                                       // Surekli olarak not girilebilmesini sa�lamak icin.
		  printf("Harf notu giriniz (Cikis icin H ya da h giriniz):");  
		  scanf("%s",&x);
		  if(x=='a' || x=='A'){																			//Girilen degerleri okuyup islemek icin.
		  	at+=1;
		  	top+=4;
		  	printf("Onaylandi....\n");
		    }
		  	else if(x=='b' || x=='B'){																	//Girilen degerleri okuyup islemek icin.
		  		bt+=1;
		  		top+=3;
		  		printf("Onaylandi....\n");
			  }
			  else if(x=='c' || x=='C'){																//Girilen degerleri okuyup islemek icin.
		  		ct+=1;
		  		top+=2;
		  		printf("Onaylandi....\n");
			  }
			  else if(x=='f' || x=='F'){																//Girilen degerleri okuyup islemek icin.
		  		ft+=1;
		  		top+=0;
		  		printf("Onaylandi....\n");
			  }
			else if(x=='h' || x=='H'){																	//Donguyu bitirmek icin.
				i++;
		  		printf("Onaylandi....\n");
			  }
		  	
		  	else 																						//Hatali girilen degeri bildirmek icin.
		  		printf("Hatali giris\n");																
	} 
	ort=top/(at+bt+ct+ft);
		printf("-----------------------------------\n");												//Sonuclari ekrana yazdirmak icin.
		printf("Girilen A larin sayisi: %d\n",at);
		printf("Girilen B larin sayisi: %d\n",bt);
		printf("Girilen C larin sayisi: %d\n",ct);
		printf("Girilen F larin sayisi: %d\n",ft);
		printf("Toplam harf sayisi: %d\n",at+bt+ct+ft);
	 	printf("Toplam puan: %.2f\n",top);
	 	printf("Ortalama not:%.4f",ort);
	return 0;
}
